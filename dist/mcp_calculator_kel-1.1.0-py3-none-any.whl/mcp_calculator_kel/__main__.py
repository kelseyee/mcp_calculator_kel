from mcp_calculator_kel import main

main()