from mcp_wiki_kel import main

main()